/*
	PROGRAMMER'S NAME : G SRIHARSHA
	ROLLNO:111601005
	PROGRAM DESCRIPTION : calculating distance betweeen 2 vertices
	DATE=7/11/17   				*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "queue.h"
#include "readWriteBfs.h"

void calculateDistance(char a[100][100],int n,int dist[n][n]);
void distanceBetween2Vertices(int n,int parent[n], int i,int *ptrdist);
void average(int n,int dist[n][n]);

void main()
{
	char a[100][100],filename[50];
	int n,n1,n2,i=1,j=0,*ptrdist,distance;
	
	ptrdist=&distance;
	*ptrdist=0;

	printf("\n Enter the file name: ");//enter the input filename
	scanf("%s",filename);
	
	//printf("%s111\n",filename );
	n=readmatrix(a,filename); //function to read adjacent matrix from the input file
	int dist[n][n];
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			//printf("%c ",a[i][j] );
			dist[i][j]=-1;
			if (i==j)
			{
				dist[i][j]=0;	/* code */
			}
		}

		//printf("\n");
	}
	//printf("hai\n");
	calculateDistance(a,n,dist);
	//printf("hi\n");
 	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			printf(" %d",dist[i][j]);
		}
		printf("\n");
	}

 	writeDotfile(a,n,filename,dist);
 	 
 	average(n,dist);
}
void average(int n,int dist[n][n])
{
	int sum=0,k;
	float average;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (dist[i][j]==-1 && i!=j)
			{
				printf("\n Graph is disconnected");
				return;
			}
		}
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = i; j < n; j++)
		{
			if (dist[i][j]!=-1)
			{
				sum=sum+dist[i][j];
				k++;
			}
		}
	}

	printf("\n sum %d ",sum);
	average = ((float)sum/k);
	printf("\n Average is %f\n",average);
}
void calculateDistance(char a[100][100],int n,int dist[n][n])
{
	int k=0,parent[n],visited[n];
	int *ptrdist,distance;
	ptrdist=&distance;
	
	//printf("qw\n");
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			k=0;
			for (int l = 0; l < n ; l++)
			{
				parent[l]=0;
				visited[l]=0;
				// for(m=0;m<n;m++)
				// {
				// 	connect[l][m]=-1;
				// }
			}

			// for (int p = 0; p < n; p++)
			// {
			// 	if (visited[p]==0)
			// 	{
			// 		q=BreadthFirstSearch(a,n,i,visited,parent,connect[k]);
			// 		q++;
			// 	}
			// }
			k=BreadthFirstSearch(a,n,i,j,parent,visited);
			// if(k==-1)
			// {
			// 	dist[i][j]=-1;
			// 	dist[j][i]=-1;
			// }
			if (k==1)
			{
				*ptrdist=0;
				distanceBetween2Vertices(n,parent,j,ptrdist);
				if (i!=j)
				{
					dist[i][j]=*ptrdist;
					dist[j][i]=*ptrdist;
				}
				
			}
		}
	}
	//printf("as\n");

}
void distanceBetween2Vertices(int n,int parent[n], int i,int *ptrdist)// function which prints the path between two nodes 
{
    if(parent[i]==-1)
    {
		return;
    }
    (*ptrdist)= (*ptrdist)+1;
    distanceBetween2Vertices(n,parent, parent[i],ptrdist);
}
