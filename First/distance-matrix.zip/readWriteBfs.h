








int readmatrix(char a[100][100],char filename[50]);
void writeDotfile(char a[100][100],int n,char filename[50],int dist[n][n]);
int BreadthFirstSearch(char a[100][100],int n,int n1,int n2,int parent[n],int visited[n]);
