/*
Name - Arpit Singh
Roll number - 111601031
Program : This program is suppose to find the shortest path between x and y in the graph 
*/


//including the important libraries
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <stdbool.h>


//including the header files
#include "graph.h"
#include "queue.h"


int * BFS (struct Graph *graph , int start , int*wTree)
//this function takes the graph ,start value and return the min distance of each vertex from the start vertex , it also returns the nodes that are visited
{
	
	int n = graph -> vc;
	Queue Q = newQueue ();
	int visited[n];
	int *level = (int*)malloc(n * sizeof(int));

	for (int i= 0 ; i < n ; i++)
		level[i] = -1;


	//making all the nodes unvisited
	for (int i =0 ; i < n ; i++)
		visited[i] = 0;


	for (int i =0 ; i < n ; i++)
		wTree[i] = -1;



	enQueue (&Q , start);
	visited[start] = 1;
	wTree[start] = 0;			//set distance of the starting node from itself to be equal to zero
	level[start] = 0;

	while (QueueisEmpty (Q) == 0)
	{
		int vertex = deQueue (&Q);

		//checking all the neighbours
		for (int i =0 ; i < n ; i++)
		{
			if (graph -> a[vertex][i] != 0)
			{

				//if i is not visited
				if (visited[i] != 1)
				{
					//this line updates the value of the wTree of i
					wTree[i] = wTree[vertex] + graph->a[vertex][i];
					level[i] = level[vertex] + 1;

					visited[i] = 1;
					enQueue(&Q , i);
				}
			}
		}
	}

	return level;



}


int inside (int *shortest , int x , int distance)
//returns 1 if x is in shortest
{
	int n = distance ;
	for (int i = 0 ; i< n ;i++)
		if (shortest[i] == x)
			return 1;

	return 0;
}


void makeGraph (struct Graph *graph , FILE *file , int *path , int distance)
//This function prints the graph taking in mind the shortest path between two nodes and higlight that in the red color
{
	//asking for the name of the output file
		char output[100];
		printf("Enter the name of the output file in which you want to show the shortest path\n");
		scanf("%s",output);

	//opening the output file
		file = fopen (output , "w");




	//printing the necesssary details
		fprintf(file , "graph one\n");
		fprintf(file , "{\n");


		int n = graph -> vc;
		for (int i =0 ; i < n ; i++)
		{
			for (int j = i ; j < n ; j++)
			{
				if (graph ->a[i][j] != 0 )
                    {
						if (inside(path , i , distance) == 0 || inside(path , j , distance) == 0)
                        	fprintf(file , "%d -- %d [color = black , label = %d];\n" , i , j , graph->a[i][j]);

                    	else
                    		fprintf(file , "%d -- %d [color = red , label = %d];\n" , i , j , graph->a[i][j]);                        
                    }
            }
		}

		//printing the isolated vertices
		int flag;

		for (int i =0 ; i < n ; i++)
		{
			flag = 0;

			for (int j =0 ; j < n ; j++)
				if (graph->a[i][j] != 0)
					flag = 1;

			if (flag == 0)
				fprintf( file , "%d;\n", i );
		}


		fprintf(file , "}\n");
}


int main ()
{
	char filename[100];
	printf("Enter the name of the file \n");
	scanf("%s",filename);

	struct Graph graph;
	int check = readGraph (filename , &graph);

	if (check == 0)
		return 0;

	int n = graph.vc;

	//making the graph 
	FILE *file;
	makeSimpleGraph (&graph , file);

	//scanning the values of the starting and the ending vertex
	int start , goal;
	printf("Enter the starting and the ending vertexn\n");
	scanf("%d %d", &start , &goal);

	int wTree[n];
	
	int *level = BFS (&graph , start , wTree);

	if (level[goal] == -1)
	{
		printf("There is no path between the starting and the ending vertex\n");
		return 0;
	}
	//finding the distance
	int distance = 0;


	for (int i =0 ; i < n ; i++)
		printf("%d  ",wTree[i]);

	printf("\n");


	


	int *path = (int *)malloc (n * sizeof (level[goal] - level[start] + 1));

	path[level[goal] - level[start]] = goal;

	for (int currentLevel = level[goal] - 1 ; currentLevel >= 0 ; currentLevel--)
	{
			int min = wTree[path[currentLevel + 1]];
			int minVertex = path[currentLevel + 1];
		for (int i = 0 ; i < n ; i++)
		{
	
			if (level[i] == currentLevel && graph.a[i][path[currentLevel + 1]] != 0 && min >= wTree[i] )
			{
				min = wTree[i];
				minVertex = i;
			}
	}
					path[currentLevel] = minVertex;
					distance += wTree[path[currentLevel + 1]] - wTree[minVertex]; 
	}

	//printing the distance between the starting and the closing node
	printf("The distance between the starting and goal vertex is %d\n",distance);

	printf("the path is \n");
	for (int i =0 ; i <= level[goal] - level[start] ; i++)
		printf("%d  ", path[i]);

	printf("\n");


	//printing the file with red color and  labeled weights
	FILE *finalfile;
	makeGraph (&graph , finalfile , path , level[goal] - level[start] + 1);



	//end of the program
	return 0;








}