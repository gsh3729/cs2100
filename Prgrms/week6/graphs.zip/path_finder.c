/*
Name - Arpit Singh
Roll number - 111601031
PC IP - 10.64.1.163
serial number - D
*/

//Note that the associativity followed here is left associativity

//declaring all the libraries
	#include <stdio.h>
	#include <stdlib.h>
	#include <limits.h>
	#include <string.h>

//declaring the structure which contains information about graphs
struct queue
{
	int data;
	struct queue * next;
};

typedef struct queue * Queue;
Queue rear (Queue q);
int QueueFront (Queue q);
int queueIsEmpty (Queue q);
int QueueSize (Queue q);
void deQueue (Queue *q);
void enQueue (Queue *q , int x);
Queue newQueue ();

struct graphs
{
	int vc;
	int **a;
	char graphName[30];

};




//declaring all the necessary functions
	int readGraph (char filename[] , struct graphs* graph );
	void printGraph (struct graphs* graph);
	void makeGraph (struct graphs* graph , FILE *file);

        int Breadth_First_search(struct graphs*graph, int Root, int Goal)
        {
                int n = graph->vc;

                //create empty set Checked
                int check[n];
                for (int i =0 ; i < n ; i++)
                {
                        check[i] = 0;

                }
                //create empty queue Queue
                Queue queue = newQueue ();

                //add Root to Checked
                check[Root] = 1;
                enQueue(&queue , Root);
                int current;
                while (queueIsEmpty(queue) != 1)
                {

                        current = QueueFront(queue);
                        deQueue (&queue);

                        if (current == Goal){
                                return 1;
                        }

                for (int i =0 ; i < n ; i++)
                {
                        printf("Hiii\n");
                        if (graph->a[current][i] == 1)
                        {
                                if (check[i] == 0 )
                                {
                                        check[i] = 1;
                                        enQueue (&queue , i);
                                }
                        }
                }
                return 0;


        }
}

int main ()
{
        char filename[100];
        printf("Enter the name of the file from which you want to \n");
        scanf("%s",filename);

        struct graphs graph;
        int check = readGraph (filename , &graph);

        //checking if the file entered is correct or not
        if (check == 0)
        return 0;
        strcpy (graph.graphName , "Graph01");

        printf("Enter the value of the nodes\n");
        int node1 , node2;
        scanf("%d %d",&node1 , &node2);

        int success ;

        success = Breadth_First_search (&graph , node1 , node2);
        if (success == 1)
        {
                printf("The shortest path is found\n");
        }
        else
        printf("The path is not found\n");
        return 0;

}

int readGraph (char filename[] , struct graphs* graph)
//this function takes the AM file as the input and then scans the matrix and then return the matrix
{
        FILE * file1;
        file1 = fopen (filename , "r");



        if (file1 == 0)
        {
                printf("error in opening the file\n");
                return 0;
        }

        char temp[1000];
        int success;
        success = fscanf(file1 , "%s" , temp);
        success = fscanf (file1 , "%s" , temp);



        success = fscanf(file1 , "%d" , &graph -> vc);


        int n = graph -> vc;
        graph ->a = (int **)malloc (n * sizeof (int *));
        for (int i = 0 ; i < n ; i++)
        {
                graph ->a[i] = (int *)malloc(n * sizeof(int));
        }



        int counter = 0;
        do
        {
                success = fscanf(file1 , "%s" , temp);

                if (success == -1)
                        break;
                for (int i =0 ; i < n ; i++)
                {
                        graph -> a[counter][i] = temp[i] - '0';

                }


                counter++;

        }while (success != -1);


        fclose(file1);

        return 1;


}

void printGraph (struct graphs *graph)
//this function just prints the graph
{
        printf("The graph name is %s\n" , graph->graphName);
        printf("The number of vertices are %d\n" , graph -> vc);

        int n = graph -> vc;

        printf("The matrix is \n");
        for (int i =0 ; i < n ; i++)
        {
                for (int j =0 ; j< n ; j++)
                {
                        printf("%d ",graph->a[i][j]);
                }
                printf("\n");
        }
}

void makeGraph ( struct graphs* graph , FILE *file)
{
        //for the output file
        char output[100];
        printf("Enter the name of the output file\n");
        scanf("%s",output);

        file = fopen (output , "w");
        fprintf(file , "graph one\n" );
        fprintf(file , "{\n");

        int n = graph->vc;
        for (int i =0 ; i < n ; i++)
        {
                for (int j =i ; j< n ; j++)
                {
                        if (graph->a[i][j] == 1)
                        {
                                fprintf(file , "%d -- %d;\n" , i , j);
                        }
                }
        }
        fprintf(file , "}\n");
}



Queue newQueue ()
//This function returns an empty queue
{
	Queue temp = NULL;
	return temp;
}

Queue rear (Queue q)
{
	Queue current = NULL;
	current = q;
	while (current -> next == q)
	{
		current = current -> next;
	}
	return current;
}

void enQueue (Queue *q , int x)
{
	Queue temp = (Queue)malloc(sizeof (struct queue));
	temp -> data = x;

	if (*q == NULL)
	{
		temp ->next = temp;
		*q = temp;
	}

	else
	{
		Queue tail = rear (*q);
		tail -> next = temp;
		temp -> next = *q;
	}
}

void deQueue (Queue *q)
{
	if (*q == NULL)
	{
		printf("The Queue is empty\n");
	}

	else
	{

		Queue tail = rear(*q);
		if (tail == *q)
		{
			*q = NULL;
		}

		else
		{
			tail -> next = (*q) -> next;
			*q = (*q) -> next;
		}
	}
}

int QueueSize (Queue q)
{
	if (q == NULL)
		return 0;

	else
	{
		int size = 0;
		Queue current = NULL;
		current = q;
		size = 1;

		while (current -> next != q)
		{
			size++;
			current = current -> next;
		}

		return size;
	}
}

int queueIsEmpty (Queue q)
{
	if (q == NULL)
		return 1;
	else
		return 0;
}

int QueueFront (Queue q)
{
        return q->data;
}
