


int BFS( Graph *g , int x , int y);          //breadth first search function to check if x and y are connected
