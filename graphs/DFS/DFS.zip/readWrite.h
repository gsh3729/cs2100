/*
	PROGRAMMER'S NAME : G SRIHARSHA
	ROLLNO:111601005
	PROGRAM DESCRIPTION : 
	PROGRAM NAME :readWrite.h
	*/

void writeDotfile(int n,char b[n][n]);
int readmatrix(char a[100][100]);
