








int readmatrix(char a[100][100]);
void writeDotfile(char a[100][100],int n);
int BreadthFirstSearch(char a[100][100],int n,int n1,int visited[],int parent[n]);
